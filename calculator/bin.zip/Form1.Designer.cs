﻿namespace calculator
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.uselessbutton = new System.Windows.Forms.Button();
            this.buttonInt = new System.Windows.Forms.Button();
            this.buttondms = new System.Windows.Forms.Button();
            this.buttonpi = new System.Windows.Forms.Button();
            this.buttonFE = new System.Windows.Forms.Button();
            this.buttonExp = new System.Windows.Forms.Button();
            this.buttontanh = new System.Windows.Forms.Button();
            this.buttoncosh = new System.Windows.Forms.Button();
            this.buttonsinh = new System.Windows.Forms.Button();
            this.buttonInv = new System.Windows.Forms.Button();
            this.buttonlog = new System.Windows.Forms.Button();
            this.buttoncube = new System.Windows.Forms.Button();
            this.buttonpower = new System.Windows.Forms.Button();
            this.buttonsquare = new System.Windows.Forms.Button();
            this.buttonbracketf = new System.Windows.Forms.Button();
            this.buttonMod = new System.Windows.Forms.Button();
            this.buttontan = new System.Windows.Forms.Button();
            this.buttoncos = new System.Windows.Forms.Button();
            this.buttonsin = new System.Windows.Forms.Button();
            this.buttonln = new System.Windows.Forms.Button();
            this.buttondot = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.buttonC = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.buttonCE = new System.Windows.Forms.Button();
            this.button0 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.buttonbackspace = new System.Windows.Forms.Button();
            this.button10x = new System.Windows.Forms.Button();
            this.button3sqrt = new System.Windows.Forms.Button();
            this.buttonexraction = new System.Windows.Forms.Button();
            this.buttonfactorial = new System.Windows.Forms.Button();
            this.buttonbracketb = new System.Windows.Forms.Button();
            this.buttonequal = new System.Windows.Forms.Button();
            this.buttoninverse = new System.Windows.Forms.Button();
            this.buttonpercent = new System.Windows.Forms.Button();
            this.buttonsqrt = new System.Windows.Forms.Button();
            this.buttonadd = new System.Windows.Forms.Button();
            this.buttonsubtract = new System.Windows.Forms.Button();
            this.buttonmultiply = new System.Windows.Forms.Button();
            this.buttondivide = new System.Windows.Forms.Button();
            this.buttonnegative = new System.Windows.Forms.Button();
            this.buttonMm = new System.Windows.Forms.Button();
            this.buttonMp = new System.Windows.Forms.Button();
            this.buttonMS = new System.Windows.Forms.Button();
            this.buttonMR = new System.Windows.Forms.Button();
            this.buttonMC = new System.Windows.Forms.Button();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // uselessbutton
            // 
            this.uselessbutton.Enabled = false;
            this.uselessbutton.Location = new System.Drawing.Point(39, 198);
            this.uselessbutton.Name = "uselessbutton";
            this.uselessbutton.Size = new System.Drawing.Size(74, 47);
            this.uselessbutton.TabIndex = 0;
            this.uselessbutton.UseVisualStyleBackColor = true;
            // 
            // buttonInt
            // 
            this.buttonInt.Location = new System.Drawing.Point(39, 251);
            this.buttonInt.Name = "buttonInt";
            this.buttonInt.Size = new System.Drawing.Size(74, 47);
            this.buttonInt.TabIndex = 1;
            this.buttonInt.Text = "Int";
            this.buttonInt.UseVisualStyleBackColor = true;
            // 
            // buttondms
            // 
            this.buttondms.Location = new System.Drawing.Point(39, 304);
            this.buttondms.Name = "buttondms";
            this.buttondms.Size = new System.Drawing.Size(74, 47);
            this.buttondms.TabIndex = 2;
            this.buttondms.Text = "dms";
            this.buttondms.UseVisualStyleBackColor = true;
            // 
            // buttonpi
            // 
            this.buttonpi.Location = new System.Drawing.Point(39, 357);
            this.buttonpi.Name = "buttonpi";
            this.buttonpi.Size = new System.Drawing.Size(74, 47);
            this.buttonpi.TabIndex = 3;
            this.buttonpi.Text = "pi";
            this.buttonpi.UseVisualStyleBackColor = true;
            this.buttonpi.Click += new System.EventHandler(this.buttonpi_Click);
            // 
            // buttonFE
            // 
            this.buttonFE.Location = new System.Drawing.Point(39, 410);
            this.buttonFE.Name = "buttonFE";
            this.buttonFE.Size = new System.Drawing.Size(74, 47);
            this.buttonFE.TabIndex = 4;
            this.buttonFE.Text = "F-E";
            this.buttonFE.UseVisualStyleBackColor = true;
            // 
            // buttonExp
            // 
            this.buttonExp.Location = new System.Drawing.Point(119, 410);
            this.buttonExp.Name = "buttonExp";
            this.buttonExp.Size = new System.Drawing.Size(74, 47);
            this.buttonExp.TabIndex = 9;
            this.buttonExp.Text = "Exp";
            this.buttonExp.UseVisualStyleBackColor = true;
            this.buttonExp.Click += new System.EventHandler(this.buttonExp_Click);
            // 
            // buttontanh
            // 
            this.buttontanh.Location = new System.Drawing.Point(119, 357);
            this.buttontanh.Name = "buttontanh";
            this.buttontanh.Size = new System.Drawing.Size(74, 47);
            this.buttontanh.TabIndex = 8;
            this.buttontanh.Text = "tanh";
            this.buttontanh.UseVisualStyleBackColor = true;
            this.buttontanh.Click += new System.EventHandler(this.buttontanh_Click);
            // 
            // buttoncosh
            // 
            this.buttoncosh.Location = new System.Drawing.Point(119, 304);
            this.buttoncosh.Name = "buttoncosh";
            this.buttoncosh.Size = new System.Drawing.Size(74, 47);
            this.buttoncosh.TabIndex = 7;
            this.buttoncosh.Text = "cosh";
            this.buttoncosh.UseVisualStyleBackColor = true;
            this.buttoncosh.Click += new System.EventHandler(this.buttoncosh_Click);
            // 
            // buttonsinh
            // 
            this.buttonsinh.Location = new System.Drawing.Point(119, 251);
            this.buttonsinh.Name = "buttonsinh";
            this.buttonsinh.Size = new System.Drawing.Size(74, 47);
            this.buttonsinh.TabIndex = 6;
            this.buttonsinh.Text = "sinh";
            this.buttonsinh.UseVisualStyleBackColor = true;
            this.buttonsinh.Click += new System.EventHandler(this.buttonsinh_Click);
            // 
            // buttonInv
            // 
            this.buttonInv.Location = new System.Drawing.Point(119, 198);
            this.buttonInv.Name = "buttonInv";
            this.buttonInv.Size = new System.Drawing.Size(74, 47);
            this.buttonInv.TabIndex = 5;
            this.buttonInv.Text = "Inv";
            this.buttonInv.UseVisualStyleBackColor = true;
            // 
            // buttonlog
            // 
            this.buttonlog.Location = new System.Drawing.Point(279, 410);
            this.buttonlog.Name = "buttonlog";
            this.buttonlog.Size = new System.Drawing.Size(74, 47);
            this.buttonlog.TabIndex = 19;
            this.buttonlog.Text = "log";
            this.buttonlog.UseVisualStyleBackColor = true;
            // 
            // buttoncube
            // 
            this.buttoncube.Location = new System.Drawing.Point(279, 357);
            this.buttoncube.Name = "buttoncube";
            this.buttoncube.Size = new System.Drawing.Size(74, 47);
            this.buttoncube.TabIndex = 18;
            this.buttoncube.Text = "x^3";
            this.buttoncube.UseVisualStyleBackColor = true;
            this.buttoncube.Click += new System.EventHandler(this.buttoncube_Click);
            // 
            // buttonpower
            // 
            this.buttonpower.Location = new System.Drawing.Point(279, 304);
            this.buttonpower.Name = "buttonpower";
            this.buttonpower.Size = new System.Drawing.Size(74, 47);
            this.buttonpower.TabIndex = 17;
            this.buttonpower.Text = "x^y";
            this.buttonpower.UseVisualStyleBackColor = true;
            // 
            // buttonsquare
            // 
            this.buttonsquare.Location = new System.Drawing.Point(279, 251);
            this.buttonsquare.Name = "buttonsquare";
            this.buttonsquare.Size = new System.Drawing.Size(74, 47);
            this.buttonsquare.TabIndex = 16;
            this.buttonsquare.Text = "x^2";
            this.buttonsquare.UseVisualStyleBackColor = true;
            this.buttonsquare.Click += new System.EventHandler(this.buttonsquare_Click);
            // 
            // buttonbracketf
            // 
            this.buttonbracketf.Location = new System.Drawing.Point(279, 198);
            this.buttonbracketf.Name = "buttonbracketf";
            this.buttonbracketf.Size = new System.Drawing.Size(74, 47);
            this.buttonbracketf.TabIndex = 15;
            this.buttonbracketf.Text = "(";
            this.buttonbracketf.UseVisualStyleBackColor = true;
            // 
            // buttonMod
            // 
            this.buttonMod.Location = new System.Drawing.Point(199, 410);
            this.buttonMod.Name = "buttonMod";
            this.buttonMod.Size = new System.Drawing.Size(74, 47);
            this.buttonMod.TabIndex = 14;
            this.buttonMod.Text = "Mod";
            this.buttonMod.UseVisualStyleBackColor = true;
            // 
            // buttontan
            // 
            this.buttontan.Location = new System.Drawing.Point(199, 357);
            this.buttontan.Name = "buttontan";
            this.buttontan.Size = new System.Drawing.Size(74, 47);
            this.buttontan.TabIndex = 13;
            this.buttontan.Text = "tan";
            this.buttontan.UseVisualStyleBackColor = true;
            this.buttontan.Click += new System.EventHandler(this.buttontan_Click);
            // 
            // buttoncos
            // 
            this.buttoncos.Location = new System.Drawing.Point(199, 304);
            this.buttoncos.Name = "buttoncos";
            this.buttoncos.Size = new System.Drawing.Size(74, 47);
            this.buttoncos.TabIndex = 12;
            this.buttoncos.Text = "cos";
            this.buttoncos.UseVisualStyleBackColor = true;
            this.buttoncos.Click += new System.EventHandler(this.buttoncos_Click);
            // 
            // buttonsin
            // 
            this.buttonsin.Location = new System.Drawing.Point(199, 251);
            this.buttonsin.Name = "buttonsin";
            this.buttonsin.Size = new System.Drawing.Size(74, 47);
            this.buttonsin.TabIndex = 11;
            this.buttonsin.Text = "sin";
            this.buttonsin.UseVisualStyleBackColor = true;
            this.buttonsin.Click += new System.EventHandler(this.buttonsin_Click);
            // 
            // buttonln
            // 
            this.buttonln.Location = new System.Drawing.Point(199, 198);
            this.buttonln.Name = "buttonln";
            this.buttonln.Size = new System.Drawing.Size(74, 47);
            this.buttonln.TabIndex = 10;
            this.buttonln.Text = "ln";
            this.buttonln.UseVisualStyleBackColor = true;
            this.buttonln.Click += new System.EventHandler(this.buttonln_Click);
            // 
            // buttondot
            // 
            this.buttondot.Location = new System.Drawing.Point(599, 410);
            this.buttondot.Name = "buttondot";
            this.buttondot.Size = new System.Drawing.Size(74, 47);
            this.buttondot.TabIndex = 39;
            this.buttondot.Text = ".";
            this.buttondot.UseVisualStyleBackColor = true;
            this.buttondot.Click += new System.EventHandler(this.buttondot_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(599, 357);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(74, 47);
            this.button3.TabIndex = 38;
            this.button3.Text = "3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(599, 304);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(74, 47);
            this.button6.TabIndex = 37;
            this.button6.Text = "6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(599, 251);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(74, 47);
            this.button9.TabIndex = 36;
            this.button9.Text = "9";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // buttonC
            // 
            this.buttonC.Location = new System.Drawing.Point(599, 198);
            this.buttonC.Name = "buttonC";
            this.buttonC.Size = new System.Drawing.Size(74, 47);
            this.buttonC.TabIndex = 35;
            this.buttonC.Text = "C";
            this.buttonC.UseVisualStyleBackColor = true;
            this.buttonC.Click += new System.EventHandler(this.buttonC_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(519, 357);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(74, 47);
            this.button2.TabIndex = 33;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(519, 304);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(74, 47);
            this.button5.TabIndex = 32;
            this.button5.Text = "5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(519, 251);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(74, 47);
            this.button8.TabIndex = 31;
            this.button8.Text = "8";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // buttonCE
            // 
            this.buttonCE.Location = new System.Drawing.Point(519, 198);
            this.buttonCE.Name = "buttonCE";
            this.buttonCE.Size = new System.Drawing.Size(74, 47);
            this.buttonCE.TabIndex = 30;
            this.buttonCE.Text = "CE";
            this.buttonCE.UseVisualStyleBackColor = true;
            this.buttonCE.Click += new System.EventHandler(this.buttonCE_Click);
            // 
            // button0
            // 
            this.button0.Location = new System.Drawing.Point(439, 410);
            this.button0.Name = "button0";
            this.button0.Size = new System.Drawing.Size(154, 47);
            this.button0.TabIndex = 29;
            this.button0.Text = "0";
            this.button0.UseVisualStyleBackColor = true;
            this.button0.Click += new System.EventHandler(this.button0_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(439, 357);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(74, 47);
            this.button1.TabIndex = 28;
            this.button1.Text = "1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(439, 304);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(74, 47);
            this.button4.TabIndex = 27;
            this.button4.Text = "4";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(439, 251);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(74, 47);
            this.button7.TabIndex = 26;
            this.button7.Text = "7";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // buttonbackspace
            // 
            this.buttonbackspace.Location = new System.Drawing.Point(439, 198);
            this.buttonbackspace.Name = "buttonbackspace";
            this.buttonbackspace.Size = new System.Drawing.Size(74, 47);
            this.buttonbackspace.TabIndex = 25;
            this.buttonbackspace.Text = "←";
            this.buttonbackspace.UseVisualStyleBackColor = true;
            this.buttonbackspace.Click += new System.EventHandler(this.buttonbackspace_Click);
            // 
            // button10x
            // 
            this.button10x.Location = new System.Drawing.Point(359, 410);
            this.button10x.Name = "button10x";
            this.button10x.Size = new System.Drawing.Size(74, 47);
            this.button10x.TabIndex = 24;
            this.button10x.Text = "10^x";
            this.button10x.UseVisualStyleBackColor = true;
            this.button10x.Click += new System.EventHandler(this.button10x_Click);
            // 
            // button3sqrt
            // 
            this.button3sqrt.Location = new System.Drawing.Point(359, 357);
            this.button3sqrt.Name = "button3sqrt";
            this.button3sqrt.Size = new System.Drawing.Size(74, 47);
            this.button3sqrt.TabIndex = 23;
            this.button3sqrt.Text = "3√x";
            this.button3sqrt.UseVisualStyleBackColor = true;
            this.button3sqrt.Click += new System.EventHandler(this.button3sqrt_Click);
            // 
            // buttonexraction
            // 
            this.buttonexraction.Location = new System.Drawing.Point(359, 304);
            this.buttonexraction.Name = "buttonexraction";
            this.buttonexraction.Size = new System.Drawing.Size(74, 47);
            this.buttonexraction.TabIndex = 22;
            this.buttonexraction.Text = "y√x";
            this.buttonexraction.UseVisualStyleBackColor = true;
            // 
            // buttonfactorial
            // 
            this.buttonfactorial.Location = new System.Drawing.Point(359, 251);
            this.buttonfactorial.Name = "buttonfactorial";
            this.buttonfactorial.Size = new System.Drawing.Size(74, 47);
            this.buttonfactorial.TabIndex = 21;
            this.buttonfactorial.Text = "n!";
            this.buttonfactorial.UseVisualStyleBackColor = true;
            this.buttonfactorial.Click += new System.EventHandler(this.buttonfactorial_Click);
            // 
            // buttonbracketb
            // 
            this.buttonbracketb.Location = new System.Drawing.Point(359, 198);
            this.buttonbracketb.Name = "buttonbracketb";
            this.buttonbracketb.Size = new System.Drawing.Size(74, 47);
            this.buttonbracketb.TabIndex = 20;
            this.buttonbracketb.Text = ")";
            this.buttonbracketb.UseVisualStyleBackColor = true;
            // 
            // buttonequal
            // 
            this.buttonequal.Location = new System.Drawing.Point(759, 357);
            this.buttonequal.Name = "buttonequal";
            this.buttonequal.Size = new System.Drawing.Size(74, 100);
            this.buttonequal.TabIndex = 49;
            this.buttonequal.Text = "=";
            this.buttonequal.UseVisualStyleBackColor = true;
            this.buttonequal.Click += new System.EventHandler(this.buttonequal_Click);
            // 
            // buttoninverse
            // 
            this.buttoninverse.Location = new System.Drawing.Point(759, 304);
            this.buttoninverse.Name = "buttoninverse";
            this.buttoninverse.Size = new System.Drawing.Size(74, 47);
            this.buttoninverse.TabIndex = 47;
            this.buttoninverse.Text = "1/x";
            this.buttoninverse.UseVisualStyleBackColor = true;
            this.buttoninverse.Click += new System.EventHandler(this.buttoninverse_Click);
            // 
            // buttonpercent
            // 
            this.buttonpercent.Location = new System.Drawing.Point(759, 251);
            this.buttonpercent.Name = "buttonpercent";
            this.buttonpercent.Size = new System.Drawing.Size(74, 47);
            this.buttonpercent.TabIndex = 46;
            this.buttonpercent.Text = "%";
            this.buttonpercent.UseVisualStyleBackColor = true;
            this.buttonpercent.Click += new System.EventHandler(this.buttonpercent_Click);
            // 
            // buttonsqrt
            // 
            this.buttonsqrt.Location = new System.Drawing.Point(759, 198);
            this.buttonsqrt.Name = "buttonsqrt";
            this.buttonsqrt.Size = new System.Drawing.Size(74, 47);
            this.buttonsqrt.TabIndex = 45;
            this.buttonsqrt.Text = "√";
            this.buttonsqrt.UseVisualStyleBackColor = true;
            this.buttonsqrt.Click += new System.EventHandler(this.buttonsqrt_Click);
            // 
            // buttonadd
            // 
            this.buttonadd.Location = new System.Drawing.Point(679, 410);
            this.buttonadd.Name = "buttonadd";
            this.buttonadd.Size = new System.Drawing.Size(74, 47);
            this.buttonadd.TabIndex = 44;
            this.buttonadd.Text = "+";
            this.buttonadd.UseVisualStyleBackColor = true;
            this.buttonadd.Click += new System.EventHandler(this.buttonadd_Click);
            // 
            // buttonsubtract
            // 
            this.buttonsubtract.Location = new System.Drawing.Point(679, 357);
            this.buttonsubtract.Name = "buttonsubtract";
            this.buttonsubtract.Size = new System.Drawing.Size(74, 47);
            this.buttonsubtract.TabIndex = 43;
            this.buttonsubtract.Text = "-";
            this.buttonsubtract.UseVisualStyleBackColor = true;
            this.buttonsubtract.Click += new System.EventHandler(this.buttonsubtract_Click);
            // 
            // buttonmultiply
            // 
            this.buttonmultiply.Location = new System.Drawing.Point(679, 304);
            this.buttonmultiply.Name = "buttonmultiply";
            this.buttonmultiply.Size = new System.Drawing.Size(74, 47);
            this.buttonmultiply.TabIndex = 42;
            this.buttonmultiply.Text = "*";
            this.buttonmultiply.UseVisualStyleBackColor = true;
            this.buttonmultiply.Click += new System.EventHandler(this.buttonmultiply_Click);
            // 
            // buttondivide
            // 
            this.buttondivide.Location = new System.Drawing.Point(679, 251);
            this.buttondivide.Name = "buttondivide";
            this.buttondivide.Size = new System.Drawing.Size(74, 47);
            this.buttondivide.TabIndex = 41;
            this.buttondivide.Text = "/";
            this.buttondivide.UseVisualStyleBackColor = true;
            this.buttondivide.Click += new System.EventHandler(this.buttondivide_Click);
            // 
            // buttonnegative
            // 
            this.buttonnegative.Location = new System.Drawing.Point(679, 198);
            this.buttonnegative.Name = "buttonnegative";
            this.buttonnegative.Size = new System.Drawing.Size(74, 47);
            this.buttonnegative.TabIndex = 40;
            this.buttonnegative.Text = "±";
            this.buttonnegative.UseVisualStyleBackColor = true;
            this.buttonnegative.Click += new System.EventHandler(this.buttonnegative_Click);
            // 
            // buttonMm
            // 
            this.buttonMm.Location = new System.Drawing.Point(759, 145);
            this.buttonMm.Name = "buttonMm";
            this.buttonMm.Size = new System.Drawing.Size(74, 47);
            this.buttonMm.TabIndex = 54;
            this.buttonMm.Text = "M-";
            this.buttonMm.UseVisualStyleBackColor = true;
            // 
            // buttonMp
            // 
            this.buttonMp.Location = new System.Drawing.Point(679, 145);
            this.buttonMp.Name = "buttonMp";
            this.buttonMp.Size = new System.Drawing.Size(74, 47);
            this.buttonMp.TabIndex = 53;
            this.buttonMp.Text = "M+";
            this.buttonMp.UseVisualStyleBackColor = true;
            // 
            // buttonMS
            // 
            this.buttonMS.Location = new System.Drawing.Point(599, 145);
            this.buttonMS.Name = "buttonMS";
            this.buttonMS.Size = new System.Drawing.Size(74, 47);
            this.buttonMS.TabIndex = 52;
            this.buttonMS.Text = "MS";
            this.buttonMS.UseVisualStyleBackColor = true;
            // 
            // buttonMR
            // 
            this.buttonMR.Location = new System.Drawing.Point(519, 145);
            this.buttonMR.Name = "buttonMR";
            this.buttonMR.Size = new System.Drawing.Size(74, 47);
            this.buttonMR.TabIndex = 51;
            this.buttonMR.Text = "MR";
            this.buttonMR.UseVisualStyleBackColor = true;
            // 
            // buttonMC
            // 
            this.buttonMC.Location = new System.Drawing.Point(439, 145);
            this.buttonMC.Name = "buttonMC";
            this.buttonMC.Size = new System.Drawing.Size(74, 47);
            this.buttonMC.TabIndex = 50;
            this.buttonMC.Text = "MC";
            this.buttonMC.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(39, 155);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(51, 22);
            this.radioButton1.TabIndex = 55;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "度";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(168, 155);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(69, 22);
            this.radioButton2.TabIndex = 56;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "弧度";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(311, 155);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(69, 22);
            this.radioButton3.TabIndex = 57;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "梯度";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("宋体", 16F);
            this.label1.Location = new System.Drawing.Point(47, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(785, 71);
            this.label1.TabIndex = 58;
            this.label1.Text = "0";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(43, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(788, 31);
            this.label2.TabIndex = 59;
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(894, 491);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.radioButton3);
            this.Controls.Add(this.radioButton2);
            this.Controls.Add(this.radioButton1);
            this.Controls.Add(this.buttonMm);
            this.Controls.Add(this.buttonMp);
            this.Controls.Add(this.buttonMS);
            this.Controls.Add(this.buttonMR);
            this.Controls.Add(this.buttonMC);
            this.Controls.Add(this.buttonequal);
            this.Controls.Add(this.buttoninverse);
            this.Controls.Add(this.buttonpercent);
            this.Controls.Add(this.buttonsqrt);
            this.Controls.Add(this.buttonadd);
            this.Controls.Add(this.buttonsubtract);
            this.Controls.Add(this.buttonmultiply);
            this.Controls.Add(this.buttondivide);
            this.Controls.Add(this.buttonnegative);
            this.Controls.Add(this.buttondot);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.buttonC);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.buttonCE);
            this.Controls.Add(this.button0);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.buttonbackspace);
            this.Controls.Add(this.button10x);
            this.Controls.Add(this.button3sqrt);
            this.Controls.Add(this.buttonexraction);
            this.Controls.Add(this.buttonfactorial);
            this.Controls.Add(this.buttonbracketb);
            this.Controls.Add(this.buttonlog);
            this.Controls.Add(this.buttoncube);
            this.Controls.Add(this.buttonpower);
            this.Controls.Add(this.buttonsquare);
            this.Controls.Add(this.buttonbracketf);
            this.Controls.Add(this.buttonMod);
            this.Controls.Add(this.buttontan);
            this.Controls.Add(this.buttoncos);
            this.Controls.Add(this.buttonsin);
            this.Controls.Add(this.buttonln);
            this.Controls.Add(this.buttonExp);
            this.Controls.Add(this.buttontanh);
            this.Controls.Add(this.buttoncosh);
            this.Controls.Add(this.buttonsinh);
            this.Controls.Add(this.buttonInv);
            this.Controls.Add(this.buttonFE);
            this.Controls.Add(this.buttonpi);
            this.Controls.Add(this.buttondms);
            this.Controls.Add(this.buttonInt);
            this.Controls.Add(this.uselessbutton);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button uselessbutton;
        private System.Windows.Forms.Button buttonInt;
        private System.Windows.Forms.Button buttondms;
        private System.Windows.Forms.Button buttonpi;
        private System.Windows.Forms.Button buttonFE;
        private System.Windows.Forms.Button buttonExp;
        private System.Windows.Forms.Button buttontanh;
        private System.Windows.Forms.Button buttoncosh;
        private System.Windows.Forms.Button buttonsinh;
        private System.Windows.Forms.Button buttonInv;
        private System.Windows.Forms.Button buttonlog;
        private System.Windows.Forms.Button buttoncube;
        private System.Windows.Forms.Button buttonpower;
        private System.Windows.Forms.Button buttonsquare;
        private System.Windows.Forms.Button buttonbracketf;
        private System.Windows.Forms.Button buttonMod;
        private System.Windows.Forms.Button buttontan;
        private System.Windows.Forms.Button buttoncos;
        private System.Windows.Forms.Button buttonsin;
        private System.Windows.Forms.Button buttonln;
        private System.Windows.Forms.Button buttondot;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button buttonC;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button buttonCE;
        private System.Windows.Forms.Button button0;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button buttonbackspace;
        private System.Windows.Forms.Button button10x;
        private System.Windows.Forms.Button button3sqrt;
        private System.Windows.Forms.Button buttonexraction;
        private System.Windows.Forms.Button buttonfactorial;
        private System.Windows.Forms.Button buttonbracketb;
        private System.Windows.Forms.Button buttonequal;
        private System.Windows.Forms.Button buttoninverse;
        private System.Windows.Forms.Button buttonpercent;
        private System.Windows.Forms.Button buttonsqrt;
        private System.Windows.Forms.Button buttonadd;
        private System.Windows.Forms.Button buttonsubtract;
        private System.Windows.Forms.Button buttonmultiply;
        private System.Windows.Forms.Button buttondivide;
        private System.Windows.Forms.Button buttonnegative;
        private System.Windows.Forms.Button buttonMm;
        private System.Windows.Forms.Button buttonMp;
        private System.Windows.Forms.Button buttonMS;
        private System.Windows.Forms.Button buttonMR;
        private System.Windows.Forms.Button buttonMC;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

